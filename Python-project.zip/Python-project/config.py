# config.py

class Config:
    # A secret key used for cryptographic operations, such as signing session cookies
    SECRET_KEY = 'this_should_be_a_secret'  
    
    # Path to the SQLite database file, which will be used for storing user data
    DATABASE = 'app.db'      
