from app import create_app  
from app.models.user import User


# run.py

# Import the create_app factory function from the app package (defined in app/__init__.py)

# Call the create_app function to create an instance of the Flask application
app = create_app()

# Check if the script is being run directly (not imported as a module)
if __name__ == '__main__':
    # Run the Flask application in debug mode (useful for development)
    app.run(debug=True)
