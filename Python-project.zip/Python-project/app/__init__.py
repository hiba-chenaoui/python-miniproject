# Import the Flask class from the flask module
from flask import Flask

# Import the user blueprint from the user_controller module in the app.controllers package
from app.controllers.user_controller import user_bp

from app.controllers.auth_controller import auth_bp

# Import the Config class from the config module
from config import Config

# Define a function to create and configure the Flask application
def create_app():
    # Create an instance of the Flask application
    app = Flask(__name__)
    
    # Load configuration settings (e.g., secret key) from the Config class
    app.config.from_object(Config)

    # Register the user blueprint (routes) with the Flask application
    app.register_blueprint(user_bp)

    app.register_blueprint(auth_bp)

    # Return the configured Flask application instance
    return app
