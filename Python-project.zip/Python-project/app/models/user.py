from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3

class User:
    def __init__(self, id=None, first_name=None, last_name=None, email=None, password=None):
        self.id = id
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.password = password

    @staticmethod
    def get_by_email(email):
        # Fetch a user by email
        conn = sqlite3.connect('app.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
        user_data = cursor.fetchone()
        conn.close()
        if user_data:
            return User(id=user_data[0], first_name=user_data[1], last_name=user_data[2], email=user_data[3], password=user_data[4])
        return None

    @staticmethod
    def create(first_name, last_name, email, password):
        # Create a new user in the database
        hashed_password = generate_password_hash(password)
        conn = sqlite3.connect('app.db')
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO users (first_name, last_name, email, password)
                          VALUES (?, ?, ?, ?)''', (first_name, last_name, email, hashed_password))
        conn.commit()
        conn.close()

    def check_password(self, password):
        # Verify the given password with the stored hash
        return check_password_hash(self.password, password)
