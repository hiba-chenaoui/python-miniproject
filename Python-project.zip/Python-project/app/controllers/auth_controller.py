from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from ..models.user import User  # Import the User model

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Get form data
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        password = request.form['password']

        # Check if email already exists using the User model
        existing_user = User.get_by_email(email)
        if existing_user:
            return render_template('signup.html', error="Email already registered.")

        # Create the new user
        User.create(first_name, last_name, email, password)

        # Redirect to login
        return redirect(url_for('auth.login'))

    return render_template('signup.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.get_by_email(email)  # Use the User model to get the user by email
        if user and user.check_password(password):  # Check the password using the model method
            session['user_id'] = user.id  # Store user id in the session
            session['username'] = user.first_name  # Store first name in session for display
            flash("You are now logged in!", "success")
            return redirect(url_for('user.home'))
        else:
            flash("Incorrect email or password", "danger")

    return render_template('login.html')


@auth_bp.route('/logout')
def logout():
    session.clear()  # Clear all session data
    return redirect(url_for('auth.login'))
