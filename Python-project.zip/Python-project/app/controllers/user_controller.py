# Import the Blueprint class and render_template function from Flask
from flask import Blueprint, render_template, session , redirect, url_for


# Create a blueprint named 'user' with the current module's name
user_bp = Blueprint('user', __name__)

# Define a route for the home page ('/') and associate it with the home function
@user_bp.route('/')

def home():
    
    if 'user_id' in session:
        return render_template('home.html', username=session.get('username'))
    else: 
        return redirect(url_for('auth.login'))